package com.pinkreminder.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Pink = Color(0xFFC62970)
private val PalePink = Color(0xFFFFF0F6)
private val Ink = Color(0xFF42283A)

data class Appointment(val id: Long, val title: String, val details: String, val at: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        setContent { PinkReminderApp() }
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                "pink_reminders", "Appointment reminders", android.app.NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

@Composable
fun PinkReminderApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pink_reminder", Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    var tab by remember { mutableStateOf(0) }
    var appointments by remember { mutableStateOf(loadAppointments(prefs)) }
    var showAdd by remember { mutableStateOf(false) }
    var showPermissionInfo by remember { mutableStateOf(false) }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> showPermissionInfo = !granted }

    val ar = !english
    val title = if (ar) "بينك ريميندر" else "Pink Reminder"
    val labels = if (ar) listOf("الرئيسية", "مواعيدي", "التوعية", "الإعدادات")
                 else listOf("Home", "Appointments", "Learn", "Settings")

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Pink, onPrimary = Color.White, secondary = Color(0xFFF18BB5),
            background = Color(0xFFFFFAFC), surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFFFFAFC),
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(42.dp).background(PalePink, CircleShape), contentAlignment = Alignment.Center) {
                        Text("🎀", fontSize = 23.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pink)
                        Text(if (ar) "صحتكِ أولويتنا" else "Your health, our priority", fontSize = 12.sp, color = Ink.copy(alpha = .7f))
                    }
                    TextButton(onClick = {
                        english = !english
                        prefs.edit().putBoolean("english", english).apply()
                    }) { Text(if (english) "العربية" else "EN", color = Pink, fontWeight = FontWeight.Bold) }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val icons = listOf(Icons.Default.Home, Icons.Default.CalendarMonth, Icons.Default.MenuBook, Icons.Default.Settings)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Pink, indicatorColor = PalePink, selectedTextColor = Pink)
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab == 1 || tab == 0) {
                    FloatingActionButton(onClick = { showAdd = true }, containerColor = Pink, contentColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = if (ar) "إضافة موعد" else "Add appointment")
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(ar, appointments, onAdd = { showAdd = true }, onGoAppointments = { tab = 1 })
                1 -> AppointmentScreen(ar, appointments, onAdd = { showAdd = true }, onDelete = { item ->
                    cancelReminder(context, item.id)
                    appointments = appointments.filterNot { it.id == item.id }
                    saveAppointments(prefs, appointments)
                })
                2 -> EducationScreen(ar)
                else -> SettingsScreen(ar, onToggleLanguage = {
                    english = !english
                    prefs.edit().putBoolean("english", english).apply()
                }, english = english)
            }
        }
    }

    if (showAdd) {
        AddAppointmentDialog(ar, onDismiss = { showAdd = false }, onSave = { name, details, at ->
            val item = Appointment(System.currentTimeMillis(), name, details, at)
            appointments = (appointments + item).sortedBy { it.at }
            saveAppointments(prefs, appointments)
            scheduleReminder(context, item, ar)
            showAdd = false
            if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        })
    }
    if (showPermissionInfo) {
        AlertDialog(
            onDismissRequest = { showPermissionInfo = false },
            title = { Text(if (ar) "فعّلي الإشعارات" else "Enable notifications") },
            text = { Text(if (ar) "لرؤية التذكيرات، اسمحي للتطبيق بإرسال الإشعارات من إعدادات الهاتف." else "Allow notifications in phone settings to receive reminders.") },
            confirmButton = { TextButton(onClick = { showPermissionInfo = false }) { Text(if (ar) "حسنًا" else "OK") } }
        )
    }
}

@Composable
private fun HomeScreen(ar: Boolean, appointments: List<Appointment>, onAdd: () -> Unit, onGoAppointments: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PalePink), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text(if (ar) "أنتِ تستحقين الاهتمام 💗" else "You deserve care 💗", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Pink)
                    Spacer(Modifier.height(8.dp))
                    Text(if (ar) "خطوة صغيرة اليوم قد تساعدكِ على الاهتمام بصحتكِ غدًا." else "A small step today can help you care for your health tomorrow.", color = Ink, lineHeight = 22.sp)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (ar) "أضيفي تذكيرًا" else "Add a reminder")
                    }
                }
            }
        }
        item { SectionTitle(if (ar) "مواعيدك القادمة" else "Upcoming appointments") }
        if (appointments.isEmpty()) {
            item { EmptyCard(ar, onAdd) }
        } else {
            items(appointments.take(3), key = { it.id }) { AppointmentCard(ar, it) }
        }
        item { SectionTitle(if (ar) "تذكير صحي" else "Health note") }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Favorite, contentDescription = null, tint = Pink, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (ar) "إذا لاحظتِ كتلة جديدة أو تغيّرًا غير معتاد في الثدي، تواصلي مع مختص صحي. التطبيق للتوعية ولا يشخّص المرض."
                        else "If you notice a new lump or unusual breast change, contact a healthcare professional. This app educates; it does not diagnose.",
                        color = Ink, lineHeight = 21.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun AppointmentScreen(ar: Boolean, appointments: List<Appointment>, onAdd: () -> Unit, onDelete: (Appointment) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (ar) "مواعيدي" else "My appointments", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pink)
        Spacer(Modifier.height(6.dp))
        Text(if (ar) "أضيفي المواعيد التي أوصى بها الطبيب." else "Add appointments recommended by your clinician.", color = Ink.copy(alpha = .75f))
        Spacer(Modifier.height(14.dp))
        if (appointments.isEmpty()) {
            EmptyCard(ar, onAdd)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(appointments, key = { it.id }) { item ->
                    AppointmentCard(ar, item, onDelete = { onDelete(item) })
                }
            }
        }
    }
}

@Composable
private fun AppointmentCard(ar: Boolean, item: Appointment, onDelete: (() -> Unit)? = null) {
    val fmt = remember { SimpleDateFormat("EEE, dd MMM yyyy • HH:mm", if (ar) Locale("ar") else Locale.ENGLISH) }
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(PalePink, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Pink)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold, color = Ink)
                if (item.details.isNotBlank()) Text(item.details, color = Ink.copy(alpha = .7f), fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text(fmt.format(Date(item.at)), color = Pink, fontSize = 12.sp)
            }
            if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, contentDescription = if (ar) "حذف" else "Delete", tint = Pink) }
        }
    }
}

@Composable
private fun EmptyCard(ar: Boolean, onAdd: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.EventAvailable, contentDescription = null, tint = Pink, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(8.dp))
            Text(if (ar) "لا توجد مواعيد بعد" else "No appointments yet", fontWeight = FontWeight.Bold)
            Text(if (ar) "أضيفي موعدًا لتلقي تذكير به." else "Add an appointment to set a reminder.", color = Ink.copy(alpha = .7f))
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onAdd) { Text(if (ar) "إضافة موعد" else "Add appointment") }
        }
    }
}

@Composable
private fun EducationScreen(ar: Boolean) {
    val cards = if (ar) listOf(
        "علامات تستحق الانتباه" to "كتلة أو سماكة جديدة، تغيّر في حجم أو شكل الثدي، تغيّرات الجلد أو الحلمة، أو إفراز غير معتاد. راجعي مختصًا صحيًا عند ملاحظة تغيّر.",
        "الفحص والتصوير" to "الفحوصات المناسبة تختلف حسب العمر والتاريخ الصحي وعوامل الخطورة. اسألي الطبيب عن خطة الفحص المناسبة لكِ.",
        "معلومة مهمة" to "معظم كتل الثدي ليست سرطانًا، لكن لا يمكن تحديد السبب بالتطبيق وحده. التقييم الطبي هو الخطوة الصحيحة."
    ) else listOf(
        "Changes to notice" to "A new lump or thickening, changes in breast size or shape, skin or nipple changes, or unusual discharge. Contact a healthcare professional if you notice a change.",
        "Screening" to "Recommended screening depends on age, health history, and risk factors. Ask a clinician which plan is right for you.",
        "Important to know" to "Most breast lumps are not cancer, but an app cannot identify the cause. Medical assessment is the right next step."
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
        item { Text(if (ar) "التوعية الصحية" else "Health education", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pink) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PalePink), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(if (ar) "المعرفة تمنحكِ قوة" else "Knowledge empowers you", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pink)
                    Text(if (ar) "التوعية والتشخيص المبكر مهمان. هذه المعلومات لا تستبدل استشارة الطبيب." else "Awareness and timely diagnosis matter. This information does not replace medical advice.", color = Ink)
                }
            }
        }
        items(cards) { (heading, body) ->
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(17.dp)) {
                    Text(heading, fontWeight = FontWeight.Bold, color = Pink, fontSize = 17.sp)
                    Spacer(Modifier.height(7.dp))
                    Text(body, color = Ink, lineHeight = 22.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(ar: Boolean, onToggleLanguage: () -> Unit, english: Boolean) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (ar) "الإعدادات" else "Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pink)
        Card(shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, contentDescription = null, tint = Pink)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (ar) "لغة التطبيق" else "App language", fontWeight = FontWeight.Bold)
                    Text(if (english) "English" else "العربية", color = Ink.copy(alpha = .7f))
                }
                TextButton(onClick = onToggleLanguage) { Text(if (ar) "English" else "العربية") }
            }
        }
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(if (ar) "الخصوصية والسلامة" else "Privacy & safety", fontWeight = FontWeight.Bold, color = Pink)
                Spacer(Modifier.height(6.dp))
                Text(if (ar) "تُحفظ المواعيد محليًا على هذا الجهاز في هذا النموذج. لا تدخلي معلومات طبية حساسة. التطبيق للتوعية والتذكير فقط وليس للتشخيص أو العلاج." else "This prototype stores appointments locally on this device. Avoid entering sensitive medical details. It is for awareness and reminders, not diagnosis or treatment.", lineHeight = 21.sp)
            }
        }
        Text(if (ar) "Pink Reminder • نموذج أولي 1.0" else "Pink Reminder • Prototype 1.0", color = Ink.copy(alpha = .55f), fontSize = 12.sp)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun AddAppointmentDialog(ar: Boolean, onDismiss: () -> Unit, onSave: (String, String, Long) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(if (ar) "موعد طبي" else "Medical appointment") }
    var details by remember { mutableStateOf("") }
    val cal = remember { Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) } }
    var chosenTime by remember { mutableLongStateOf(cal.timeInMillis) }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (ar) "إضافة تذكير" else "Add reminder", color = Pink, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(if (ar) "عنوان الموعد" else "Appointment title") }, singleLine = true)
                OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text(if (ar) "ملاحظة (اختياري)" else "Note (optional)") }, singleLine = true)
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = chosenTime }
                    DatePickerDialog(context, { _, year, month, day ->
                        c.set(year, month, day)
                        chosenTime = c.timeInMillis
                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                }, modifier = Modifier.fillMaxWidth()) { Text((if (ar) "التاريخ: " else "Date: ") + fmt.format(Date(chosenTime))) }
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = chosenTime }
                    TimePickerDialog(context, { _, hour, minute ->
                        c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0)
                        chosenTime = c.timeInMillis
                    }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                }, modifier = Modifier.fillMaxWidth()) { Text(if (ar) "اختيار الوقت" else "Choose time") }
                Text(if (ar) "سيصدر التذكير في الموعد المحدد. تأكدي من السماح بالإشعارات." else "A reminder is scheduled for this time. Allow notifications.", fontSize = 12.sp, color = Ink.copy(alpha = .7f))
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank() && chosenTime > System.currentTimeMillis()) onSave(name.trim(), details.trim(), chosenTime) }, colors = ButtonDefaults.buttonColors(containerColor = Pink)) { Text(if (ar) "حفظ" else "Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (ar) "إلغاء" else "Cancel") } }
    )
}

private fun saveAppointments(prefs: android.content.SharedPreferences, items: List<Appointment>) {
    val array = JSONArray()
    items.forEach { a -> array.put(JSONObject().put("id", a.id).put("title", a.title).put("details", a.details).put("at", a.at)) }
    prefs.edit().putString("appointments", array.toString()).apply()
}
private fun loadAppointments(prefs: android.content.SharedPreferences): List<Appointment> {
    return try {
        val array = JSONArray(prefs.getString("appointments", "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Appointment(o.getLong("id"), o.getString("title"), o.getString("details"), o.getLong("at"))
        }.filter { it.at > System.currentTimeMillis() }.sortedBy { it.at }
    } catch (_: Exception) { emptyList() }
}
private fun scheduleReminder(context: Context, item: Appointment, ar: Boolean) {
    val intent = Intent(context, ReminderReceiver::class.java).apply {
        putExtra("title", if (ar) "تذكير من Pink Reminder" else "Pink Reminder")
        putExtra("details", "${item.title}${if (item.details.isNotBlank()) " — ${item.details}" else ""}")
    }
    val pending = PendingIntent.getBroadcast(
        context, item.id.hashCode(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.at, pending)
}
private fun cancelReminder(context: Context, id: Long) {
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, id.hashCode(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
}
