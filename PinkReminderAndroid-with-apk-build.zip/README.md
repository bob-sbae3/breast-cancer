# Pink Reminder — Android starter project

A bilingual (Arabic/English) Kotlin + Jetpack Compose prototype for breast-cancer awareness and appointment reminders.

## Included
- Home screen and upcoming appointment list
- Add appointment title, optional note, date and time
- Local scheduled notification reminder
- Delete appointment and cancel its reminder
- Arabic/English toggle
- Awareness information and safety disclaimer
- Appointment data stored locally using SharedPreferences

## Build and run
1. Install Android Studio: https://developer.android.com/studio
2. Unzip this project.
3. In Android Studio choose **Open**, then select the `PinkReminderAndroid` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35.
5. Create an Android emulator, or connect an Android phone with Developer Options and USB debugging enabled.
6. Press **Run ▶**.
7. When adding the first appointment, allow notifications. Android 13+ requires explicit notification permission.

## Important prototype notes
- Reminder timing uses `AlarmManager.setAndAllowWhileIdle`; Android may delay alarms under battery restrictions. It is not an exact-alarm medical alert system.
- Reminders are scheduled when the appointment is added. This prototype does not yet restore alarms after reboot, synchronize across devices, back up data, or provide a privacy/security audit.
- Data is stored on the device only. Avoid entering sensitive health details.
- Educational text is general and does not diagnose or replace a clinician. Screening intervals should be personalized by a qualified healthcare professional.

## Suggested next upgrades
- Reliable reboot rescheduling and tests across Android versions
- Edit appointments, recurring reminders and reminder lead-time settings
- Encrypted storage and clear privacy policy
- Content reviewed by local clinicians and localized for Lebanon
- Accessibility testing and app icon
